## Blogstorm WP Plugin
Blogstorm WP Plugin is developed to let you connect to [Blogstorm](https://app.blogstorm.ai/), an AI-based content creation platform.

Blogstorm allows you to automated PAA, and SERP based content, and publish them to your wordpress sites, with featured image, meta description and all.
