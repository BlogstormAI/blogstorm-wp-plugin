=== Blogstorm ===
Contributors: Blogstorm
Tags: AI content, AI writing automation, seo writing
Tested up to: 6.2
Requires at least: 4.9
Requires PHP: 5.6
Stable tag: 1.1.3
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

AI automation content creation tool for 1-click SEO-optimized articles, blog posts & affiliate content. With long/short form content, seo optimized meta tags and cool AI generated images. 

== Description ==

Blogstorm WP Plugin is developed to let you connect to [Blogstorm](https://demo.blogstorm.ai/), an AI-based content creation platform.

Blogstorm allows you to automated PAA, and SERP based content, and publish them to your wordpress sites, with featured image, meta description and all.

== Changelog ==

= 1.0.0 =
* Publish content from Blogstorm to WordPress.
